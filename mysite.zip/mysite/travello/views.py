from django.shortcuts import render
from .models import Destination

# Create your views here.



def index(request):
    destlists=Destination.objects.all()
    return render(request,'index.html',{'destlist':destlists})